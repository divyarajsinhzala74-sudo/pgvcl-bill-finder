# PGVCL Bill Finder V3

Consumer-friendly monthly bill portal for a master PGVCL PDF where each consumer bill is one page.

## Workflow
1. Office opens `/admin` on phone.
2. Enter admin password, bill month (YYYY-MM), and monthly master PDF.
3. Server scans the PDF, extracts Consumer Number, and saves each page as an individual PDF.
4. Consumer opens `/` and enters only Consumer Number.
5. The latest bill is returned with View/Download PDF.

## Important
- Do not upload master PDFs to public GitHub repositories.
- Change `ADMIN_PASSWORD` before deployment.
- Use HTTPS in production.
- This version assumes one consumer bill per PDF page and extracts `Consumer No:` from the page text.
- Storage is local to the server. Choose a host with persistent disk/storage for production.

## Local run
`npm install`
`ADMIN_PASSWORD='strong-password' npm start`
